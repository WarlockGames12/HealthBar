using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(AudioSource))]
public class GetHitByEnemy : MonoBehaviour
{
    public CameraFollowPlayer DestroyCamera;
    public AudioClip PlayClip;
    public static bool GameOver = false;
    public GameObject GameOverScreen;
    public GameObject Player;
    public HealthBar healthbar;
    public int maxHealth = 100;
    public int currentHealth;
   

    void Start()
    {
        GameOverScreen.SetActive(false);
        currentHealth = maxHealth;
        healthbar.SetMaxHealth(maxHealth);
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            TakeDamage(20);
            AudioSource audio = GetComponent<AudioSource>();
            audio.clip = PlayClip;
            audio.Play();
            if(currentHealth == 0)
            {
                audio.Play();
                GameOverScreen.SetActive(true);
                Destroy(DestroyCamera);
                Destroy(Player);
            }
        }
    }

    void TakeDamage(int damage)
    {
        currentHealth -= damage;
        healthbar.SetHealth(currentHealth);
    }
}
